package org.example.opplabproject;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;

public class StudentFormGUI extends Application {

    private TextField nameField;
    private TextField idField;
    private ToggleGroup genderToggleGroup;
    private ComboBox<String> provinceBox;
    private DatePicker datePicker;

    private final String fileName = "studentData.txt";

    @Override
    public void start(Stage primaryStage) {
        VBox vbox = new VBox();
        vbox.setSpacing(20);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);


        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(20);
        pane.setPadding(new Insets(10));
        pane.setAlignment(Pos.CENTER);


        Label nameLabel = new Label("Full Name:");
        nameField = new TextField();
        nameLabel.setStyle("-fx-font-size: 16px");
        nameField.setStyle("-fx-background-color: white; -fx-border-color: black;");
        nameField.setPromptText("Enter Full Name");
        pane.add(nameLabel, 0, 0);
        pane.add(nameField, 1, 0);


        Label idLabel = new Label("ID:");
        idField = new TextField();
        idLabel.setStyle("-fx-font-size: 16px");
        idField.setStyle("-fx-font-size: 16px");
        idField.setStyle("-fx-background-color: white; -fx-border-color: black;");
        idField.setPromptText("Enter ID");
        pane.add(idLabel, 0, 1);
        pane.add(idField, 1, 1);


        Label genderLabel = new Label("Gender:");
        genderLabel.setStyle("-fx-font-size: 16px");
        genderToggleGroup = new ToggleGroup();
        RadioButton male = new RadioButton("Male");
        RadioButton female = new RadioButton("Female");
        male.setToggleGroup(genderToggleGroup);
        female.setToggleGroup(genderToggleGroup);
        HBox genderBox = new HBox(15, male, female);
        genderBox.setAlignment(Pos.CENTER_LEFT);
        pane.add(genderLabel, 0, 2);
        pane.add(genderBox, 1, 2);


        Label provinceLabel = new Label("Province:");
        provinceLabel.setStyle("-fx-font-size: 16px");
        provinceBox = new ComboBox<>();
        provinceBox.setValue("Select Province...");
        provinceBox.getItems().addAll("Punjab", "Sindh", "KPK", "Balochistan", "Gilgit Baltistan");
        provinceBox.setStyle("-fx-background-color: white; -fx-border-color: black;");
        pane.add(provinceLabel, 0, 3);
        pane.add(provinceBox, 1, 3);


        Label dobLabel = new Label("DOB:");
        dobLabel.setStyle("-fx-font-size: 16px");
        datePicker = new DatePicker();
        datePicker.setValue(LocalDate.now());
        datePicker.setStyle("-fx-background-color: white; -fx-border-color: black;");
        pane.add(dobLabel, 0, 4);
        pane.add(datePicker, 1, 4);


        Button newButton = new Button("New");
        newButton.setStyle("-fx-background-color: blue; -fx-font-size: 16px; -fx-text-fill: white; -fx-cursor: pointer; -fx-padding: 10px 30px 10px 30px");
        Button findButton = new Button("Find");
        findButton.setStyle("-fx-background-color: blue; -fx-font-size: 16px; -fx-text-fill: white; -fx-cursor: pointer; -fx-padding: 10px 30px 10px 30px");
        HBox buttonsBox = new HBox(20, newButton, findButton);
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.setPadding(new Insets(10));


        newButton.setOnAction(e -> saveData());
        findButton.setOnAction(e -> findDataById());

        vbox.getChildren().addAll(pane, buttonsBox);


        Scene scene = new Scene(vbox, 400, 350);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Form");
        primaryStage.show();
    }

    private void saveData() {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileName, true))) {
            String fullName = nameField.getText();
            String id = idField.getText();
            String gender = ((RadioButton) genderToggleGroup.getSelectedToggle()).getText();
            String province = provinceBox.getValue();
            String dob = datePicker.getValue().toString();


            bufferedWriter.write(id + "," + fullName + "," + gender + "," + province + "," + dob);
            bufferedWriter.newLine();


            nameField.clear();
            idField.clear();
            genderToggleGroup.getSelectedToggle().setSelected(false);
            provinceBox.setValue("Select Province...");
            datePicker.setValue(LocalDate.now());

            showAlert(Alert.AlertType.INFORMATION, "Success", "Data saved successfully!");
        } catch (IOException | NullPointerException ex) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to save data. Please ensure all fields are filled.");
        }
    }

    private void findDataById() {
        String searchId = idField.getText();
        if (searchId.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter an ID to search.");
            return;
        }

        boolean found = false;
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts[0].equals(searchId)) {
                    idField.setText(parts[0]);
                    nameField.setText(parts[1]);
                    if (parts[2].equals("Male")) {
                        genderToggleGroup.selectToggle(genderToggleGroup.getToggles().get(0));
                    } else if (parts[2].equals("Female")) {
                        genderToggleGroup.selectToggle(genderToggleGroup.getToggles().get(1));
                    }
                    provinceBox.setValue(parts[3]);
                    datePicker.setValue(LocalDate.parse(parts[4]));

                    found = true;
                    break;
                }
            }

            if (!found) {
                showAlert(Alert.AlertType.INFORMATION, "Not Found", "No record found with ID: " + searchId);
            }
        } catch (FileNotFoundException ex) {
            showAlert(Alert.AlertType.ERROR, "Error", "Data file not found.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
